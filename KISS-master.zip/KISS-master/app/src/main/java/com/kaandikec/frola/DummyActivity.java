package com.kaandikec.frola;

import android.app.Activity;

/**
 * An empty activity used for changing Android's Default Launcher
 */

public class DummyActivity extends Activity {
}
