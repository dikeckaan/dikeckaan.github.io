package com.kaandikec.frola.searcher;

import com.kaandikec.frola.ui.ListPopup;

public interface QueryInterface {
    void launchOccurred();

    void registerPopup(ListPopup popup);
}
