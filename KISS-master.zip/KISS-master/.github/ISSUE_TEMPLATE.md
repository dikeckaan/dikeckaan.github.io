(please read this text, then remove it to write your issue)

Thanks for taking the time to help us improve KISS!

## Submitting a bug?
Make sure you include the following:

* app version
* android version
* device used
* custom settings that might have an impact
* one or more screenshot

## Submitting a feature request?
Make sure the issue title is descriptive enough :)
Then explain what you're looking for, what problem it will solve and feel free to include a mockup (even a Paint drawing is fine) to ensure we're all on the same page

